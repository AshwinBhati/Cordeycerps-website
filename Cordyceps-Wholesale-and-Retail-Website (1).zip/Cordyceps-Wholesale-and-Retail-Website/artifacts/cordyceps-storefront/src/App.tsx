import { useState, type FormEvent } from 'react';
import {
  ArrowDown,
  ArrowUpRight,
  BadgeCheck,
  Camera,
  CalendarDays,
  Check,
  FileText,
  Leaf,
  Mail,
  Menu,
  Minus,
  Package,
  Plus,
  ShoppingBag,
  Upload,
  X,
} from 'lucide-react';

type Product = {
  id: string;
  name: string;
  note: string;
  detail: string;
  weight: string;
  packaging: string;
  rate: string;
  image: string;
  shade: string;
};

const products: Product[] = [
  {
    id: 'small-batch',
    name: 'The small batch',
    note: 'For a first look',
    detail: 'Lab-grown cordyceps, naturally dried and carefully sorted for a first look at the ingredient.',
    weight: '15 g',
    packaging: 'Small-batch pack',
    rate: 'Rate to be added',
    image: '/cordyceps-dry-lab-grown-a.jpg',
    shade: 'bg-[#ded3bc]',
  },
  {
    id: 'pantry-jar',
    name: 'The pantry jar',
    note: 'For regular rituals',
    detail: 'Naturally dried, lab-grown cordyceps in a kitchen-sized jar for regular use and smaller orders.',
    weight: '40 g',
    packaging: 'Recyclable glass jar',
    rate: 'Rate to be added',
    image: '/cordyceps-dry-lab-grown-b.jpg',
    shade: 'bg-[#c5cfbd]',
  },
  {
    id: 'trade-case',
    name: 'The trade case',
    note: 'For your menu',
    detail: 'A larger naturally dried format for restaurants, makers, retailers and trade buying.',
    weight: '250 g',
    packaging: 'Trade case',
    rate: 'Rate to be added',
    image: '/cordyceps-dry-lab-grown-a.jpg',
    shade: 'bg-[#d7b896]',
  },
  {
    id: 'whole-dried',
    name: 'Whole dried fruiting bodies',
    note: 'For inspectable applications',
    detail: 'Whole, naturally dried lab-grown cordyceps for buyers who need a clear, inspectable format.',
    weight: 'Format enquiry',
    packaging: 'Whole dried',
    rate: 'Quote on request',
    image: '/cordyceps-dry-lab-grown-a.jpg',
    shade: 'bg-[#d9c9a7]',
  },
  {
    id: 'dried-bulk',
    name: 'Dried / bulk',
    note: 'For larger supply conversations',
    detail: 'Dried lab-grown cordyceps for buyers discussing bulk requirements, specifications and availability.',
    weight: 'Bulk / quote',
    packaging: 'Bulk supply',
    rate: 'Quote on request',
    image: '/cordyceps-dry-lab-grown-a.jpg',
    shade: 'bg-[#c7b48f]',
  },
];

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [inquiryOpen, setInquiryOpen] = useState(false);
  const [bagOpen, setBagOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [bagCount, setBagCount] = useState(0);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', business: '', message: '' });

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const addToBag = (product: Product) => {
    setSelectedProduct(product);
    setBagCount((count) => count + 1);
    setBagOpen(true);
  };

  const openInquiry = () => {
    setBagOpen(false);
    setInquiryOpen(true);
    setSent(false);
  };

  const submitInquiry = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSent(true);
  };

  return (
    <main className="min-h-[100dvh] overflow-x-hidden">
      <div className="bg-[#1e3b31] px-5 py-2.5 text-center text-[11px] font-medium tracking-[.08em] text-[#e7e4d5]">
        CONTROLLED CULTIVATION <span className="mx-2 text-[#c9955c]">/</span> B2B SUPPLY ENQUIRIES
      </div>

      <header className="sticky top-0 z-40 border-b border-[#d9d0be]/80 bg-[#f2eedf]/90 backdrop-blur-md">
        <div className="mx-auto flex h-[76px] max-w-[1320px] items-center justify-between px-5 md:px-8">
          <button type="button" onClick={() => scrollTo('top')} className="group flex items-center gap-3 text-left" data-testid="button-brand-home">
            <span className="relative flex h-9 w-9 items-center justify-center rounded-full border border-[#2e4a3d]">
              <span className="h-3 w-3 rounded-full bg-[#ba7648]" />
              <span className="absolute -right-1 top-1 h-2.5 w-2.5 rounded-full bg-[#d6a666]" />
            </span>
            <span>
              <span className="block font-serif text-[19px] font-semibold leading-none text-[#263f34]">Kora</span>
              <span className="eyebrow mt-1 block text-[8px] text-[#738071]">Field goods</span>
            </span>
          </button>

          <nav className="hidden items-center gap-8 text-[13px] font-medium text-[#486154] md:flex" aria-label="Main navigation">
            <button type="button" onClick={() => scrollTo('the-mushroom')} data-testid="link-about">About cordyceps</button>
            <button type="button" onClick={() => scrollTo('inside-the-lab')} data-testid="link-cultivation">Cultivation</button>
            <button type="button" onClick={() => scrollTo('shop')} data-testid="link-products">Products</button>
            <button type="button" onClick={() => scrollTo('documentation')} data-testid="link-quality">Quality</button>
            <button type="button" onClick={() => scrollTo('trade')} data-testid="link-trade">Wholesale</button>
            <button type="button" onClick={() => scrollTo('our-way')} data-testid="link-approach">Our approach</button>
          </nav>

          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setBagOpen(true)} className="relative flex h-10 items-center gap-2 rounded-full border border-[#cfc6b3] px-3.5 text-[12px] font-semibold text-[#294a3b] transition hover:border-[#294a3b] hover:bg-[#e8e2d1]" data-testid="button-open-bag">
              <ShoppingBag size={16} strokeWidth={1.7} />
              <span className="hidden sm:inline">Your bag</span>
              {bagCount > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#ba7648] px-1 text-[10px] text-[#fff8e9]" data-testid="text-bag-count">{bagCount}</span>}
            </button>
            <button type="button" onClick={() => setMobileOpen(!mobileOpen)} className="flex h-10 w-10 items-center justify-center rounded-full border border-[#cfc6b3] md:hidden" data-testid="button-mobile-menu" aria-label="Open menu">
              {mobileOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {mobileOpen && (
          <nav className="border-t border-[#d9d0be] px-5 py-4 md:hidden" aria-label="Mobile navigation">
            {[
              ['About cordyceps', 'the-mushroom'],
              ['Cultivation', 'inside-the-lab'],
              ['Products', 'shop'],
              ['Quality', 'documentation'],
              ['Wholesale', 'trade'],
              ['Expertise & training', 'expertise'],
              ['Our approach', 'our-way'],
              ['FAQ', 'faq'],
            ].map(([label, id]) => (
              <button key={id} type="button" onClick={() => scrollTo(id)} className="flex w-full items-center justify-between border-b border-[#ddd4c3] py-3 text-left text-sm text-[#294a3b]" data-testid={`link-mobile-${id}`}>
                {label}<ArrowUpRight size={15} />
              </button>
            ))}
          </nav>
        )}
      </header>

      <section id="top" className="grain relative bg-[#e3ddca]">
        <div className="mx-auto grid max-w-[1320px] items-stretch lg:grid-cols-[.88fr_1.12fr]">
          <div className="flex flex-col justify-center px-5 pb-16 pt-16 sm:px-10 md:pb-24 md:pt-24 lg:px-16">
            <div className="reveal flex items-center gap-3 text-[#8a5b38]">
              <span className="h-px w-8 bg-[#ba7648]" />
              <span className="eyebrow">Controlled cultivation / Cordyceps militaris</span>
            </div>
            <h1 className="reveal delay-1 mt-7 max-w-[620px] font-serif text-[clamp(3.5rem,7.1vw,7.1rem)] font-medium leading-[.92] tracking-[-.055em] text-[#234538]">
              Cultivated with<br /><em className="text-[#a8623f]">precision.</em><br />Grown for what comes next.
            </h1>
            <p className="reveal delay-2 mt-7 max-w-[450px] text-[17px] leading-7 text-[#526457]">
              Premium Cordyceps militaris cultivated in controlled environments, carefully harvested and processed for nutraceutical, wellness and functional-product applications.
            </p>
            <div className="reveal delay-3 mt-9 flex flex-wrap items-center gap-3">
              <button type="button" onClick={() => scrollTo('shop')} className="group flex items-center gap-4 rounded-full bg-[#284b3c] px-6 py-3.5 text-sm font-semibold text-[#f6f0df] transition hover:bg-[#1e392f]" data-testid="button-explore-cordyceps">
                Explore our Cordyceps <ArrowUpRight size={16} className="transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
              <button type="button" onClick={openInquiry} className="rounded-full px-4 py-3.5 text-sm font-semibold text-[#345544] underline decoration-[#b98254] underline-offset-4 hover:text-[#a8623f]" data-testid="button-start-trade">
                Wholesale enquiries <ArrowUpRight size={14} className="ml-1 inline" />
              </button>
            </div>
            <div className="mt-16 flex items-center gap-8 border-t border-[#c6baa3] pt-5 text-[#657464]">
              <div><span className="eyebrow block text-[9px] text-[#9a6846]">Cultivation</span><span className="mt-1 block text-xs">Controlled indoor</span></div>
              <div><span className="eyebrow block text-[9px] text-[#9a6846]">Quality</span><span className="mt-1 block text-xs">Batch-focused</span></div>
              <div><span className="eyebrow block text-[9px] text-[#9a6846]">Format</span><span className="mt-1 block text-xs">Whole dried</span></div>
              <div><span className="eyebrow block text-[9px] text-[#9a6846]">Supply</span><span className="mt-1 block text-xs">Enquire for volumes</span></div>
            </div>
          </div>
          <div className="relative min-h-[500px] overflow-hidden lg:min-h-[690px]">
             <img src="/cordyceps-lab-grown-hero.jpg" alt="Golden cordyceps mushrooms growing in trays inside a bright lab" className="absolute inset-0 h-full w-full object-cover" data-testid="img-hero-lab-grown-cordyceps" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#e3ddca]/20 via-transparent to-[#19382c]/10" />
            <div className="stamp absolute bottom-8 left-6 flex h-[108px] w-[108px] rotate-[-3deg] items-center justify-center rounded-full border border-[#f2eedf]/70 bg-[#af6945]/90 text-center text-[10px] font-semibold uppercase leading-4 tracking-[.14em] text-[#f9efdc] shadow-lg sm:bottom-12 sm:left-10">
              Whole<br />mushrooms<br />only
            </div>
            <div className="absolute right-6 top-7 hidden border-l border-[#f2eedf]/60 pl-3 text-[#f5eddb] sm:block">
              <span className="eyebrow text-[9px]">Kora / 001</span>
              <span className="mt-1 block text-xs">Field notes, 2025</span>
            </div>
          </div>
        </div>
        <button type="button" onClick={() => scrollTo('the-mushroom')} className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 items-center gap-2 text-[#6e7a67] md:flex" data-testid="button-scroll-story">
          <span className="eyebrow text-[9px]">Keep looking</span><ArrowDown size={14} />
        </button>
      </section>

      <section id="the-mushroom" className="bg-[#f2eedf] px-5 py-24 md:px-10 md:py-36">
        <div className="mx-auto max-w-[1180px]">
          <div className="grid gap-14 md:grid-cols-[.9fr_1.1fr] md:gap-24">
            <div>
              <span className="eyebrow text-[#ad6a43]">01 / What we grow</span>
              <h2 className="mt-5 max-w-[500px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">Cordyceps militaris,<br /><span className="text-[#ae6c48]">cultivated under control.</span></h2>
            </div>
            <div className="max-w-[570px] pt-1">
              <p className="text-xl leading-8 text-[#40594b]">We cultivate Cordyceps militaris in a controlled indoor environment, focusing on consistent growing conditions, careful harvesting and reliable batch quality.</p>
              <p className="mt-6 text-[15px] leading-7 text-[#718071]">Our focus is a clear, inspectable ingredient and a supply conversation grounded in the format, quantity and application you need.</p>
              <button type="button" onClick={() => scrollTo('inside-the-lab')} className="mt-8 flex items-center gap-2 text-sm font-semibold text-[#a76240] underline decoration-[#d4a073] underline-offset-4" data-testid="button-read-our-way">See how we grow <ArrowUpRight size={15} /></button>
            </div>
          </div>
          <div className="mt-20 grid gap-4 md:grid-cols-3">
            {[
              ['01', 'See exactly what you receive.', 'Whole fruiting bodies, carefully harvested and dried while preserving their natural structure—so every batch can be inspected before processing.'],
              ['02', 'Defined formats', 'Choose a format aligned with your application, from whole dried fruiting bodies to dried bulk.'],
              ['03', 'Clear next steps', 'Share your quantity and application and we will respond with available specifications.'],
            ].map(([num, title, text]) => (
              <article key={num} className="border-t border-[#cfc5b2] pt-5" data-testid={`card-ingredient-${num}`}>
                <span className="eyebrow text-[#af6c47]">{num}</span>
                <h3 className="mt-8 font-serif text-2xl text-[#294b3c]">{title}</h3>
                <p className="mt-3 max-w-[290px] text-sm leading-6 text-[#708073]">{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="inside-the-lab" className="grain relative overflow-hidden bg-[#ded8c6] px-5 py-24 md:px-10 md:py-32">
        <div className="relative z-10 mx-auto max-w-[1180px]">
          <div className="grid gap-10 md:grid-cols-[.75fr_1.25fr] md:items-end md:gap-24">
            <div>
              <span className="eyebrow text-[#a96040]">02 / How we grow</span>
              <h2 className="mt-5 max-w-[500px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">Grown in a<br /><em className="text-[#a76140]">controlled environment.</em></h2>
            </div>
            <div className="max-w-[520px]">
              <p className="text-xl leading-8 text-[#40594b]">From substrate preparation to fruiting and harvest, every stage is managed to create consistent growing conditions and dependable batches.</p>
              <p className="mt-4 text-sm leading-6 text-[#6b786b]">Real cultivation and packing photographs can replace these reserved frames when they are available.</p>
            </div>
          </div>

          <div className="mt-14 grid gap-4 md:grid-cols-[1.25fr_.75fr]">
            <div className="asset-slot soft-lift relative flex min-h-[390px] flex-col items-center justify-center overflow-hidden border border-[#b8bba8] px-8 text-center" data-testid="asset-slot-lab-main">
              <span className="flex h-14 w-14 items-center justify-center rounded-full border border-[#a96040]/50 bg-[#f2eedf]/70 text-[#a96040]"><Camera size={23} strokeWidth={1.5} /></span>
              <span className="eyebrow mt-6 text-[9px] text-[#a96040]">Lab photo slot 01</span>
              <h3 className="mt-3 font-serif text-3xl text-[#294b3c]">Your lab photos will appear here</h3>
              <p className="mt-3 max-w-[360px] text-sm leading-6 text-[#6c796d]">A wide view of the growing room, racks or working area can be added by the seller.</p>
              <span className="mt-6 inline-flex items-center gap-2 border-t border-[#b9b8a9] pt-3 font-mono text-[10px] uppercase tracking-[.1em] text-[#8a6750]"><Upload size={13} /> Awaiting seller upload</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-1">
              {[
                ['02', 'Detail of the growing space', 'A close view of trays, shelves or the day-to-day work.'],
                ['03', 'People behind every batch.', 'From cultivation to packing, handled with care.'],
              ].map(([num, title, text]) => (
                <div key={num} className="asset-slot soft-lift relative flex min-h-[185px] flex-col justify-end overflow-hidden border border-[#b8bba8] p-6" data-testid={`asset-slot-lab-${num}`}>
                  <span className="absolute right-6 top-6 font-mono text-[10px] text-[#a96040]">{num}</span>
                  <Camera size={20} strokeWidth={1.5} className="text-[#a96040]" />
                  <h3 className="mt-5 font-serif text-2xl text-[#294b3c]">{title}</h3>
                  <p className="mt-2 max-w-[290px] text-sm leading-5 text-[#6c796d]">{text}</p>
                  <span className="mt-4 font-mono text-[9px] uppercase tracking-[.1em] text-[#8a6750]">Photo awaiting upload</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-14 border-t border-[#b8bba8] pt-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="eyebrow text-[9px] text-[#a96040]">Cultivation process</span>
              <span className="text-xs text-[#6b786b]">A clear view of each stage</span>
            </div>
            <div className="mt-6 grid gap-2 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-8">
              {['Substrate', 'Sterilization', 'Inoculation', 'Incubation', 'Fruiting', 'Harvest', 'Drying', 'Testing'].map((stage, index) => (
                <div key={stage} className="relative border border-[#b8bba8] bg-[#e7e4d6]/65 px-3 py-4" data-testid={`process-stage-${index + 1}`}>
                  <span className="font-mono text-[9px] text-[#a96040]">0{index + 1}</span>
                  <span className="mt-3 block font-serif text-lg leading-tight text-[#294b3c]">{stage}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="shop" className="bg-[#294b3c] px-5 py-24 text-[#f2eedf] md:px-10 md:py-32">
        <div className="mx-auto max-w-[1180px]">
          <div className="flex flex-col justify-between gap-7 md:flex-row md:items-end">
            <div>
              <span className="eyebrow text-[#d4a073]">03 / Product formats</span>
              <h2 className="mt-5 max-w-[650px] font-serif text-5xl leading-[.98] tracking-[-.04em] md:text-6xl">Choose the format<br /><em className="text-[#d49a67]">that fits your application.</em></h2>
            </div>
            <p className="max-w-[330px] text-sm leading-6 text-[#bfcbbb]">Small-batch packs, pantry jars, trade cases, whole dried fruiting bodies and bulk formats for different applications.</p>
          </div>
          <div className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => (
              <article key={product.id} className={`group relative overflow-hidden ${product.shade}`} data-testid={`card-product-${product.id}`}>
                <div className="relative aspect-[.95] min-h-[440px]">
                   <img src={product.image} alt={`${product.name} naturally dried lab-grown cordyceps mushrooms`} className="absolute inset-0 h-full w-full object-cover mix-blend-multiply transition duration-700 group-hover:scale-105" data-testid={`img-product-${product.id}`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#172f26]/80 via-transparent to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-6 md:p-7">
                    <span className="eyebrow text-[#edc28f]">{product.note}</span>
                    <h3 className="mt-2 font-serif text-3xl text-[#fff6e7]">{product.name}</h3>
                    <p className="mt-2 max-w-[310px] text-sm leading-5 text-[#dedbcc]">{product.detail}</p>
                    <div className="mt-5 flex items-center justify-between border-t border-[#f2eedf]/25 pt-4">
                      <div className="min-w-0">
                        <span className="block font-mono text-xs text-[#edc28f]">{product.weight} / {product.packaging}</span>
                        <span className="mt-1 block text-xs text-[#f4d6aa]">{product.rate}</span>
                      </div>
                      <button type="button" onClick={() => addToBag(product)} className="flex h-10 w-10 items-center justify-center rounded-full bg-[#eee8d8] text-[#294b3c] transition hover:bg-[#d4a073]" data-testid={`button-add-${product.id}`} aria-label={`Add ${product.name} to bag`}><Plus size={17} /></button>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-3 border-t border-[#607464] pt-5 text-xs text-[#bfcbbb]">
            <span className="flex items-center gap-2"><BadgeCheck size={16} className="text-[#d4a073]" /> Whole format for inspection</span>
            <span className="flex items-center gap-2"><Leaf size={16} className="text-[#d4a073]" /> Jar, paper and trade formats</span>
            <span className="flex items-center gap-2"><Package size={16} className="text-[#d4a073]" /> Rates being added</span>
          </div>
        </div>
      </section>

      <section id="trade" className="bg-[#c6d0bf] px-5 py-24 md:px-10 md:py-32">
        <div className="mx-auto grid max-w-[1180px] gap-14 md:grid-cols-[.8fr_1.2fr] md:gap-24">
          <div>
             <span className="eyebrow text-[#8d593d]">07 / B2B supply</span>
             <h2 className="mt-5 max-w-[570px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">Looking for a reliable<br /><em className="text-[#a76140]">Cordyceps supply?</em></h2>
              <p className="mt-7 max-w-[390px] text-[15px] leading-7 text-[#536957]">Tell us your required format, quantity and application. We&apos;ll respond with availability, specifications and a quotation.</p>
             <button type="button" onClick={openInquiry} className="mt-8 flex items-center gap-3 rounded-full bg-[#a96040] px-5 py-3.5 text-sm font-semibold text-[#fbf1df] transition hover:bg-[#8d5137]" data-testid="button-wholesale-inquiry">Start a wholesale enquiry <ArrowUpRight size={16} /></button>
          </div>
           <div className="flex min-h-[280px] flex-col justify-between border-t border-[#aebaa9] pt-7 md:min-h-[330px]">
             <div>
               <span className="eyebrow text-[#a96040]">Wholesale enquiry</span>
               <p className="mt-6 max-w-[470px] font-serif text-4xl leading-[1.02] tracking-[-.03em] text-[#294b3c] md:text-5xl">Format, quantity and application — the details we need to prepare a clear reply.</p>
             </div>
             <div className="flex flex-wrap items-end justify-between gap-6 border-t border-[#aebaa9] pt-5">
               <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs text-[#5c705f]">
                 <span>Format</span>
                 <span>Quantity</span>
                 <span>Application</span>
               </div>
               <button type="button" onClick={openInquiry} className="flex w-fit items-center gap-3 font-mono text-xs uppercase tracking-[.1em] text-[#294b3c] underline decoration-[#a96040] underline-offset-8" data-testid="button-trade-form">Open trade form <ArrowUpRight size={15} /></button>
             </div>
          </div>
        </div>
      </section>

      <section id="applications" className="bg-[#f2eedf] px-5 py-24 md:px-10 md:py-32">
        <div className="mx-auto grid max-w-[1180px] gap-12 md:grid-cols-[.92fr_1.08fr] md:items-center md:gap-24">
          <div className="relative overflow-hidden bg-[#d9c5a3] p-5 sm:p-8" data-testid="section-applications">
            <div className="relative aspect-square overflow-hidden">
              <img src="/cordyceps-1kg-trade-pack.jpg" alt="Visual preview of a one kilogram kraft trade pack with dried cordyceps" className="h-full w-full object-cover transition duration-700 hover:scale-[1.03]" data-testid="img-one-kilogram-trade-pack" />
              <div className="absolute left-4 top-4 border border-[#f2eedf]/75 bg-[#294b3c]/85 px-3 py-2 text-[#f5eddb]">
                <span className="eyebrow text-[9px] text-[#edc28f]">Visual preview</span>
                <span className="mt-1 block font-serif text-lg">Trade pack preview</span>
              </div>
            </div>
            <p className="mt-4 font-mono text-[10px] uppercase tracking-[.08em] text-[#675c4a]" data-testid="text-trade-pack-disclaimer">Packaging shown is a trade pack preview, not the seller&apos;s final branded pack.</p>
          </div>
          <div>
            <span className="eyebrow text-[#ad6a43]">06 / Applications</span>
            <h2 className="mt-5 max-w-[530px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">Built for your<br /><em className="text-[#a76140]">application.</em></h2>
            <p className="mt-7 max-w-[480px] text-[15px] leading-7 text-[#5f7061]">For nutraceutical, wellness and functional-product applications, start with the format and quantity your work requires. We can share the available supply details through a wholesale enquiry.</p>
            <div className="mt-8 border-t border-[#d0c6b4] pt-5">
              <span className="eyebrow text-[9px] text-[#a96040]">Application conversation</span>
              <p className="mt-2 max-w-[390px] text-sm leading-6 text-[#6c796d]">Share what you are developing, the format you need and an approximate quantity. We&apos;ll reply with the relevant next steps.</p>
            </div>
            <button type="button" onClick={openInquiry} className="mt-8 flex items-center gap-3 rounded-full bg-[#294b3c] px-5 py-3.5 text-sm font-semibold text-[#f2eedf] transition hover:bg-[#1e392f]" data-testid="button-inquire-application">Discuss your application <ArrowUpRight size={16} /></button>
          </div>
        </div>
      </section>

      <section id="documentation" className="bg-[#e6ddc9] px-5 py-24 md:px-10 md:py-32">
        <div className="mx-auto max-w-[1180px]">
          <div>
            <span className="eyebrow text-[#a96040]">08 / Quality</span>
            <h2 className="mt-5 max-w-[600px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">Quality you<br /><em className="text-[#a76140]">can verify.</em></h2>
            <p className="mt-7 max-w-[570px] text-[15px] leading-7 text-[#5f7061]">Batch documentation, testing reports and cultivation information available for qualified buyers.</p>
            <p className="mt-4 max-w-[570px] text-sm leading-6 text-[#788276]">Documents will be added when the seller provides the original files. Nothing below is presented as verified until the corresponding document exists.</p>
          </div>
          <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              'COA',
              'Microbial analysis',
              'Heavy-metal testing',
              'Moisture analysis',
              'Product specification sheet',
              'Batch information',
              'Cultivation details',
              'Relevant business / certification documents',
            ].map((document) => (
              <div key={document} className="soft-lift flex min-h-[145px] flex-col justify-between border border-[#b7b7a7] bg-[#f2eedf]/55 p-5" data-testid={`document-slot-${document.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}>
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-[#a96040]/45 bg-[#f2eedf]/75 text-[#a96040]"><FileText size={18} strokeWidth={1.4} /></span>
                <div>
                  <h3 className="font-serif text-xl leading-tight text-[#294b3c]">{document}</h3>
                  <span className="mt-2 block font-mono text-[9px] uppercase tracking-[.1em] text-[#8a6750]">Awaiting original file</span>
                </div>
              </div>
            ))}
          </div>
        </div>
       </section>

      <section id="expertise" className="bg-[#f2eedf] px-5 py-24 md:px-10 md:py-36">
        <div className="mx-auto max-w-[1180px]">
          <div className="grid gap-14 md:grid-cols-[1.05fr_.95fr] md:items-center md:gap-24">
            <div className="relative min-h-[420px] overflow-hidden bg-[#d8c8a9] p-5 sm:p-8" data-testid="section-training-record">
              <div className="relative flex h-full min-h-[370px] flex-col justify-between border border-[#9d8c70] bg-[#f7f0df] p-6 shadow-[10px_10px_0_rgba(89,76,55,.16)] sm:p-9">
                <div className="flex items-start justify-between gap-5 border-b border-[#cfc2a8] pb-5">
                  <div>
                    <span className="eyebrow text-[9px] text-[#a96040]">Training record</span>
                    <h3 className="mt-3 max-w-[280px] font-serif text-3xl leading-[.98] text-[#294b3c]">Structured<br /><em className="text-[#a76140]">cultivation training</em></h3>
                  </div>
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-[#a96040]/50 text-[#a96040]"><FileText size={22} strokeWidth={1.4} /></span>
                </div>
                <div className="py-8 text-center">
                  <span className="eyebrow text-[9px] text-[#8a6750]">Verified documentation</span>
                  <p className="mx-auto mt-4 max-w-[290px] font-serif text-2xl leading-tight text-[#294b3c]">Training documentation can be added here when available.</p>
                </div>
                <div className="flex items-center justify-between gap-4 border-t border-[#cfc2a8] pt-4 font-mono text-[9px] uppercase tracking-[.1em] text-[#8a6750]">
                  <span className="flex items-center gap-2"><Upload size={13} /> Awaiting upload</span>
                  <span>Training record</span>
                </div>
              </div>
            </div>
            <div>
              <span className="eyebrow text-[#ad6a43]">09 / Expertise &amp; training</span>
              <h2 className="mt-5 max-w-[570px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">Built on<br /><em className="text-[#a76140]">cultivation knowledge.</em></h2>
              <p className="mt-7 max-w-[500px] text-[15px] leading-7 text-[#5f7061]">Our cultivation approach is informed by structured training and established mushroom-growing practices, with continuous attention to growing conditions, hygiene and batch consistency.</p>
              <div className="mt-8 grid grid-cols-2 gap-5 border-t border-[#d0c6b4] pt-5 text-sm text-[#5f7061]">
                <div><CalendarDays size={17} className="mb-3 text-[#a76140]" /><strong className="block text-[#294b3c]">Structured practice</strong><span className="mt-1 block leading-5">Training informs how each stage is approached.</span></div>
                <div><Mail size={17} className="mb-3 text-[#a76140]" /><strong className="block text-[#294b3c]">Continuous attention</strong><span className="mt-1 block leading-5">Growing conditions, hygiene and batch consistency stay in view.</span></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="our-way" className="bg-[#d7dfd0] px-5 py-24 md:px-10 md:py-32">
        <div className="mx-auto max-w-[1180px]">
          <span className="eyebrow text-[#a96040]">10 / Our approach</span>
          <div className="mt-5 flex flex-col justify-between gap-8 md:flex-row md:items-end">
            <h2 className="max-w-[620px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">A clear way to<br /><em className="text-[#a76140]">work together.</em></h2>
            <p className="max-w-[360px] text-[15px] leading-7 text-[#5f7061]">The way we build supply starts with clarity, repeatability and a format that works for your application.</p>
          </div>
          <div className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[
              ['01', 'Controlled', 'Controlled growing conditions from inoculation through fruiting.'],
              ['02', 'Consistent', 'Repeatable processes designed around batch-to-batch consistency.'],
              ['03', 'Transparent', 'Clear information about cultivation, format and available testing.'],
              ['04', 'Scalable', 'Building production capacity around reliable B2B demand.'],
            ].map(([num, title, text]) => (
              <article key={num} className="soft-lift flex min-h-[230px] flex-col justify-between border-t border-[#aebdac] pt-5" data-testid={`card-approach-${num}`}>
                <span className="eyebrow text-[#a96040]">{num}</span>
                <div>
                  <h3 className="font-serif text-3xl text-[#294b3c]">{title}</h3>
                  <p className="mt-3 text-sm leading-6 text-[#68786a]">{text}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="bg-[#f2eedf] px-5 py-24 md:px-10 md:py-32">
        <div className="mx-auto grid max-w-[1180px] gap-12 md:grid-cols-[.8fr_1.2fr] md:gap-24">
          <div>
            <span className="eyebrow text-[#a96040]">11 / FAQ</span>
            <h2 className="mt-5 max-w-[430px] font-serif text-5xl leading-[.98] tracking-[-.04em] text-[#294b3c] md:text-6xl">Useful answers<br /><em className="text-[#a76140]">before you enquire.</em></h2>
          </div>
          <div className="border-t border-[#d0c6b4]">
            {[
              ['What formats are currently shown?', 'The current range includes a 15 g small batch, a 40 g pantry jar, a 250 g trade case, whole dried fruiting bodies and dried / bulk. Rates for the retail formats will be added shortly; wholesale availability and specifications are confirmed through an enquiry.'],
              ['What should I include in an enquiry?', 'Tell us your required format, approximate quantity and application so we can respond with the relevant availability and next steps.'],
              ['What quality information can buyers request?', 'Batch documentation, testing reports and cultivation information can be made available for qualified buyers when the original documents are provided.'],
            ].map(([question, answer]) => (
              <details key={question} className="group border-b border-[#d0c6b4] py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-6 font-serif text-2xl text-[#294b3c]">
                  {question}
                  <span className="font-mono text-sm text-[#a96040] transition group-open:rotate-45">+</span>
                </summary>
                <p className="max-w-[560px] pt-4 text-sm leading-6 text-[#68786a]">{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#a96040] px-5 py-20 text-[#fcf3e4] md:px-10 md:py-28">
        <div className="mx-auto flex max-w-[1180px] flex-col justify-between gap-10 md:flex-row md:items-end">
          <div><span className="eyebrow text-[#f1c69c]">Wholesale supply</span><h2 className="mt-5 max-w-[740px] font-serif text-5xl leading-[.97] tracking-[-.04em] md:text-7xl">Need Cordyceps for<br /><em>your next formulation?</em></h2></div>
           <button type="button" onClick={openInquiry} className="flex w-fit items-center gap-3 rounded-full border border-[#f4d0aa]/60 px-5 py-3 text-sm font-semibold transition hover:bg-[#8d5137]" data-testid="button-final-cta">Talk to us <ArrowUpRight size={16} /></button>
        </div>
      </section>

      <footer className="bg-[#203d32] px-5 py-12 text-[#e8e3d4] md:px-10 md:py-16">
        <div className="mx-auto grid max-w-[1180px] gap-12 md:grid-cols-[1fr_auto_auto]">
           <div><div className="font-serif text-3xl">Kora</div><p className="mt-3 max-w-[280px] text-sm leading-6 text-[#aebdb0]">Cultivated Cordyceps militaris for nutraceutical, wellness and functional-product applications.</p><p className="eyebrow mt-8 text-[9px] text-[#c69468]">© 2025 Kora Field Goods</p></div>
            <div><span className="eyebrow text-[9px] text-[#c69468]">B2B navigation</span><div className="mt-4 grid gap-3 text-sm text-[#d8ded2]">
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={() => scrollTo('the-mushroom')} data-testid="link-footer-about">About Cordyceps</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={() => scrollTo('inside-the-lab')} data-testid="link-footer-cultivation">Cultivation</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={() => scrollTo('documentation')} data-testid="link-footer-quality">Quality</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={() => scrollTo('shop')} data-testid="link-footer-products">Products</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={() => scrollTo('applications')} data-testid="link-footer-applications">Applications</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={() => scrollTo('trade')} data-testid="link-footer-wholesale">Wholesale</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={() => scrollTo('documentation')} data-testid="link-footer-specifications">Product Specifications</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={openInquiry} data-testid="link-footer-quote">Request a Quote</button>
              <button type="button" className="text-left hover:text-[#d4a073]" onClick={openInquiry} data-testid="link-footer-contact">Contact</button>
            </div></div>
           <div><span className="eyebrow text-[9px] text-[#c69468]">Talk to us</span><p className="mt-4 max-w-[230px] text-sm leading-6 text-[#d8ded2]" data-testid="text-contact-pending">Share your format, quantity and application through the wholesale enquiry form.</p><button type="button" onClick={openInquiry} className="mt-4 text-sm font-semibold text-[#f0c28f] underline underline-offset-4" data-testid="link-footer-enquiry">Start a wholesale enquiry <ArrowUpRight size={14} className="ml-1 inline" /></button></div>
        </div>
      </footer>

      {bagOpen && (
        <div className="fixed inset-0 z-50 bg-[#152d24]/35" onClick={() => setBagOpen(false)} data-testid="overlay-bag">
          <aside className="absolute right-0 top-0 h-full w-full max-w-[410px] bg-[#f2eedf] p-6 shadow-2xl sm:p-8" onClick={(event) => event.stopPropagation()} data-testid="panel-bag">
            <div className="flex items-center justify-between border-b border-[#d3c9b7] pb-5"><div><span className="eyebrow text-[#a96040]">Your selection</span><h2 className="mt-1 font-serif text-3xl text-[#294b3c]">The bag</h2></div><button type="button" onClick={() => setBagOpen(false)} className="flex h-9 w-9 items-center justify-center rounded-full border border-[#cfc6b3]" data-testid="button-close-bag" aria-label="Close bag"><X size={17} /></button></div>
            {bagCount > 0 && selectedProduct ? (
              <div className="mt-7">
                 <div className="flex gap-4 border-b border-[#d3c9b7] pb-6"><img src={selectedProduct.image} alt="" className="h-24 w-24 object-cover" /><div className="flex-1"><h3 className="font-serif text-xl text-[#294b3c]">{selectedProduct.name}</h3><p className="mt-1 text-xs text-[#758274]">{selectedProduct.weight} / {selectedProduct.packaging}</p><p className="mt-1 text-xs text-[#a96040]">{selectedProduct.rate}</p><div className="mt-4 flex items-center gap-3 text-xs"><button type="button" onClick={() => setBagCount(Math.max(0, bagCount - 1))} className="flex h-7 w-7 items-center justify-center rounded-full border border-[#cfc6b3]" data-testid="button-decrease-bag"><Minus size={13} /></button><span data-testid="text-bag-quantity">{bagCount}</span><button type="button" onClick={() => setBagCount(bagCount + 1)} className="flex h-7 w-7 items-center justify-center rounded-full border border-[#cfc6b3]" data-testid="button-increase-bag"><Plus size={13} /></button></div></div></div>
                <p className="mt-7 text-sm leading-6 text-[#617264]">This is a presentation selection. We will confirm availability and a final quote with you before anything is committed.</p>
                <button type="button" onClick={openInquiry} className="mt-7 flex w-full items-center justify-center gap-2 rounded-full bg-[#294b3c] px-5 py-3.5 text-sm font-semibold text-[#f2eedf]" data-testid="button-enquire-selection">Enquire about this selection <ArrowUpRight size={15} /></button>
              </div>
            ) : <div className="flex h-[65%] flex-col items-center justify-center text-center"><ShoppingBag size={28} className="text-[#b77a55]" strokeWidth={1.3} /><h3 className="mt-4 font-serif text-2xl text-[#294b3c]">Nothing here yet.</h3><p className="mt-2 max-w-[230px] text-sm leading-6 text-[#758274]">Choose a format to begin the supply conversation.</p><button type="button" onClick={() => { setBagOpen(false); scrollTo('shop'); }} className="mt-6 text-sm font-semibold text-[#a96040] underline underline-offset-4" data-testid="button-browse-selection">Browse the formats</button></div>}
          </aside>
        </div>
      )}

      {inquiryOpen && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-[#152d24]/45 p-0 sm:items-center sm:p-6" onClick={() => setInquiryOpen(false)} data-testid="overlay-inquiry">
          <div className="max-h-[92dvh] w-full max-w-[620px] overflow-y-auto bg-[#f2eedf] p-6 sm:p-10" onClick={(event) => event.stopPropagation()} data-testid="dialog-inquiry">
            <div className="flex items-start justify-between"><div><span className="eyebrow text-[#a96040]">Wholesale enquiry</span><h2 className="mt-2 font-serif text-4xl leading-none text-[#294b3c]">Let&apos;s talk supply.</h2></div><button type="button" onClick={() => setInquiryOpen(false)} className="flex h-9 w-9 items-center justify-center rounded-full border border-[#cfc6b3]" data-testid="button-close-inquiry"><X size={17} /></button></div>
            {sent ? <div className="flex min-h-[340px] flex-col items-center justify-center text-center"><span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#c6d0bf] text-[#294b3c]"><Check size={22} /></span><h3 className="mt-5 font-serif text-3xl text-[#294b3c]">Message received.</h3><p className="mt-3 max-w-[340px] text-sm leading-6 text-[#657465]">Thank you, {form.name || 'there'}. We&apos;ll get back to you at {form.email || 'your email'} with the useful details.</p><button type="button" onClick={() => setInquiryOpen(false)} className="mt-7 rounded-full bg-[#294b3c] px-6 py-3 text-sm font-semibold text-[#f2eedf]" data-testid="button-close-success">Back to Kora</button></div> : <form onSubmit={submitInquiry} className="mt-8 grid gap-5"><div className="grid gap-5 sm:grid-cols-2"><label className="grid gap-2 text-xs font-semibold text-[#506454]">Your name<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="border-b border-[#bfb5a2] bg-transparent px-0 py-2.5 text-sm text-[#294b3c] outline-none placeholder:text-[#9a9c8e] focus:border-[#a96040]" placeholder="How should we address you?" data-testid="input-inquiry-name" /></label><label className="grid gap-2 text-xs font-semibold text-[#506454]">Work email<input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="border-b border-[#bfb5a2] bg-transparent px-0 py-2.5 text-sm text-[#294b3c] outline-none placeholder:text-[#9a9c8e] focus:border-[#a96040]" placeholder="you@yourbusiness.com" data-testid="input-inquiry-email" /></label></div><label className="grid gap-2 text-xs font-semibold text-[#506454]">Business name<input value={form.business} onChange={(e) => setForm({ ...form, business: e.target.value })} className="border-b border-[#bfb5a2] bg-transparent px-0 py-2.5 text-sm text-[#294b3c] outline-none placeholder:text-[#9a9c8e] focus:border-[#a96040]" placeholder="Tell us who you are building for" data-testid="input-inquiry-business" /></label><label className="grid gap-2 text-xs font-semibold text-[#506454]">What are you looking for?<textarea required rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="resize-none border-b border-[#bfb5a2] bg-transparent px-0 py-2.5 text-sm text-[#294b3c] outline-none placeholder:text-[#9a9c8e] focus:border-[#a96040]" placeholder="Your required format, approximate quantity and application." data-testid="input-inquiry-message" /></label><div className="flex flex-col justify-between gap-4 pt-2 sm:flex-row sm:items-center"><p className="max-w-[280px] text-[11px] leading-5 text-[#7b8779]">No commitment, no automated quote. We&apos;ll reply with availability, specifications and next steps.</p><button type="submit" className="flex items-center justify-center gap-2 rounded-full bg-[#294b3c] px-6 py-3.5 text-sm font-semibold text-[#f2eedf]" data-testid="button-submit-inquiry">Send enquiry <ArrowUpRight size={15} /></button></div></form>}
          </div>
        </div>
      )}
    </main>
  );
}

export default App;