# Cordyceps Wholesale & Retail Store

A visual storefront for a dry cordyceps mushroom seller serving both wholesale firms and individual customers.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/cordyceps-storefront/src/App.tsx` — single-page storefront experience and local purchase/inquiry interactions
- `artifacts/cordyceps-storefront/src/index.css` — theme tokens, typography, responsive styling, and motion
- `artifacts/cordyceps-storefront/public/` — local product imagery used by the storefront

## Architecture decisions

- The first release is presentation-first and frontend-only; retail shopping and wholesale inquiry are represented with local UI state until business details and fulfillment requirements are confirmed.
- The home page presents two clear buying paths so firms and individual customers can find the right next step without splitting the brand into separate sites.

## Product

- Product-led landing page for whole dried cordyceps mushrooms.
- Retail path with product selection, quantity controls, and a bag drawer.
- Wholesale path with a local inquiry form and success state.
- Responsive navigation and layout for desktop and mobile buyers.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
